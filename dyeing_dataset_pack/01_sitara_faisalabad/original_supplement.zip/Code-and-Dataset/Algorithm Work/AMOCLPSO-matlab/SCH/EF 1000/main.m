close all;
clear all;
clc
pop = 15;
gen = 100;
CLPSO(pop,gen)