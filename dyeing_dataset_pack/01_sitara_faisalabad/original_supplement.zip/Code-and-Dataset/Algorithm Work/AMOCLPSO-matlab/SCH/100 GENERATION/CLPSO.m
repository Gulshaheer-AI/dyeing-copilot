function CLPSO(pop,gen)
%% Simple error checking
% Number of Arguments
% Check for the number of arguments. The two input arguments are necessary
% to run this function.
if nargin < 2
    error('MOPSO: Please enter the population size and number of generations as input arguments.');
end
% Both the input arguments need to of integer data type
if isnumeric(pop) == 0 || isnumeric(gen) == 0
    error('Both input arguments pop and gen should be integer datatype');
end
% Minimum population size has to be 20 individuals
if pop < 5
    error('Minimum population for running this function is 20');
end
if gen < 5
    error('Minimum number of generations is 5');
end
% Make sure pop and gen are integers
pop = round(pop);
gen = round(gen);
%=========================================================================
%% Function range setting
% for i = 1:10
%     sphere(i,1)= -100;
%     sphere(i,2)= 100;
% end
% save sphere.txt sphere -ASCII 

%% Objective Function descreption
input_file = load ('SCH.txt');
true_optimal_front = load ('schaffer_optimal_front.txt');
[dim, c]= size(input_file);
objectives = 2;
m = dim + objectives;
vel = m + dim;
pbest = vel + dim;
best_fit = pbest + objectives;
clear c
for l = 1:dim
    min_range(l) = input_file(l,1);
    max_range(l) = input_file(l,2);
    V_max(l) = 0.25*(input_file(l,2)-input_file(l,1));
end
w0 = 0.9;
w1 = 0.4;
% w = 0.4;
c1 = 2;
final_result = [];
% %=========================================================================
for n = 1:50
    tic
%% Initialize the population of swarm
swarm = initialize_variables(pop, objectives, dim, min_range, max_range);
%% ==========================================================================
% %% Start the evolution process
for i = 1:gen
%     tic
    w = (((w0-w1)*(gen-i))/gen)+w1;
    for j = 1:pop        
        for k = 1:dim   
         aindex = ceil(pop*rand(1));
         swarm(j,m+k)= w*swarm(j,m+k)+ c1*rand(1)*(swarm(j,vel+k)- swarm(j,k)) + c1*rand(1)*(swarm(aindex,vel+k)- swarm(j,k));
%          swarm(j,m+k)= min(V_max(k),max(-V_max(k),swarm(j,m+k)));
         swarm(j,k)= swarm(j,k) + swarm(j,m+k);
         swarm(j,k)= min(max_range(k),max(min_range(k),swarm(j,k)));
        end
        swarm(j,dim+1:m) = SCH(swarm(j,1:dim), dim);        
    end  
    for j = 1:pop     
        dom_less = 0;
        dom_equal= 0;
        dom_more = 0;
         for k = 1 : objectives
            if (swarm(j,dim + k) < swarm(j,pbest+k))
                dom_less = dom_less + 1;
            elseif (swarm(j,dim + k) == swarm(j,pbest+k))
                dom_equal = dom_equal + 1;
            else
                dom_more = dom_more + 1;
            end
         end 
         if  dom_more == 0 && dom_equal ~= objectives 
             swarm(j,vel+1:pbest)= swarm(j,1:dim);
             swarm(j,pbest+1:best_fit)= swarm(j,dim+1:m);
         elseif dom_more ~= 0 && dom_less ~= 0
             if rand(1)< 0.5
                swarm(j,vel+1:pbest)= swarm(j,1:dim);
                swarm(j,pbest+1:best_fit)= swarm(j,dim+1:m);
             end
         end
    end
%% ======================================================================
           if ~mod(i,10)
                clc
                fprintf('%d Iteration in progress\n',n);
                fprintf('%d generations completed\n',i);
           end   
%            iteration_time(i)= toc;
end
    raw_rep = [];
    rep1 = [];
    raw_rep = swarm(:,vel+1:best_fit);
    raw_rep = non_domination_sort_mod1(raw_rep, objectives, dim);
    rep1 = raw_rep(1,:);
       [raw_r c] = size(raw_rep);
       clear c
         for k = 2:raw_r 
              if raw_rep(k,m+1) == 1
                 rep1 = cat(1,rep1, raw_rep(k,:));
               end
         end
    generational_distance_metic(n,1) = generational_distance(rep1,true_optimal_front,objectives);
    diversity(n,1) = deversity_metric(rep1,true_optimal_front,objectives);
    [rr1 cc1] = size(rep1);
    [rrr1 ccc1] = size(final_result);
    advances = rr1+rrr1;
    final_result(rrr1+1:advances,:)= rep1;
    iteration_time(n)= toc;
end
        gen_distance(1,1) = min(generational_distance_metic);
        gen_distance(2,1) = max(generational_distance_metic);
        gen_distance(3,1) = mean(generational_distance_metic);
        gen_distance(4,1) = median(generational_distance_metic);
        gen_distance(5,1) = std(generational_distance_metic);
        
        diversity_distance(1,1) = min(diversity);
        diversity_distance(2,1) = max(diversity);
        diversity_distance(3,1) = mean(diversity);
        diversity_distance(4,1) = median(diversity);
        diversity_distance(5,1) = std(diversity);
  
        iter_time(1,1) = min(iteration_time);
        iter_time(2,1) = max(iteration_time);
        iter_time(3,1) = mean(iteration_time);
        iter_time(4,1) = median(iteration_time);
        iter_time(5,1) = std(iteration_time);
        
        optimal_front(final_result,true_optimal_front,objectives)

%% Result
% Save the result in ASCII text format.
save gen_distance.txt gen_distance -ASCII
save diversity_distance.txt diversity_distance -ASCII
save iteration_time.txt iter_time -ASCII
save A-MOCLPSO_SCH_100.txt final_result -ASCII
end