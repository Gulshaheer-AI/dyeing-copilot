function f = SCH(x, V)
%% function f = evaluate_objective(x, M, V)
f = [];
%Objective function one
f(1) = x(1)^2;
%% Intermediate function
f(2) = (x(1)-2)^2;