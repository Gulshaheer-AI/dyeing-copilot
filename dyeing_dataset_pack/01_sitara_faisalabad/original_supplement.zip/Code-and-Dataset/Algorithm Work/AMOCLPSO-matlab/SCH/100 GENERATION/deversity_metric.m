function deversity1 = deversity_metric(front,optimal_front1,objectives)
ZDT = sortrows(front,2);
optimal_front = sortrows(optimal_front1,1);
ZDT4 = ZDT(:,2:3);
q = 1;
ZDT111(1,:)= ZDT4(1,:);
[r2 c2]= size(ZDT4);
while(r2>1)
    [r3 c3]= size(ZDT111);     
    while (sqrt(( ZDT111(r3,1)- ZDT4(1,1))^2 +( ZDT111(r3,2)- ZDT4(1,2))^2) < 0.01)  
        ZDT4(1,:)= [];
        [r2 c2]= size(ZDT4);
        if r2 == 0
            break
        end
    end
    [r2 c2]= size(ZDT4);
    if r2 ~= 0
     q = q+1;
     ZDT111(q,:)= ZDT4(1,:);
     [r2 c2]= size(ZDT4);
    end
end
% ZDT111 = ZDT(:,11:12);
for i = 1:objectives
    minimum_value(i) = min(optimal_front(:,i));
end
for i = 1:objectives
    maximum_value(i) = max(optimal_front(:,i));
end
[rows col]= size(ZDT111);
[rows1 col1]= size(optimal_front);
df = sqrt(( optimal_front(1,1)- ZDT111(1,1))^2 +( optimal_front(1,2)- ZDT111(1,2))^2);
dl = sqrt(( optimal_front(rows1,1)- ZDT111(rows,1))^2 +( optimal_front(rows1,2)- ZDT111(rows,2))^2);
for i = 1:rows-1
    distances(i) = sqrt((ZDT111(i,1)-ZDT111(i+1,1))^2 +(ZDT111(i,2)-ZDT111(i+1,2))^2);
end
if rows>=2
    mean_distance = mean(distances);
    distances = abs(distances - mean_distance);
    total_distance = sum(distances);
    deversity1 = (df+dl+total_distance)/(df+dl+(rows-1)*mean_distance);
else
    deversity1 = 1;
end