close all;
clear all;
clc
pop = 30;
gen = 100;
CLPSO(pop,gen)