close all;
clear all;
clc
pop = 20;
gen = 100;
CLPSO(pop,gen)