function optimal_front(front,true_optimal_front,objectives)
raw_rep1 = non_domination_sort_mod1(front, objectives, 1);
    rep11 = raw_rep1(1,:);
       [raw_r c] = size(raw_rep1);
       clear c
         for k = 2:raw_r 
              if raw_rep1(k,4) == 1
                 rep11 = cat(1,rep11, raw_rep1(k,:));
               end
         end
%% Result
% Save the result in ASCII text format.
save A-MOCLPSO_SCH_4000.txt rep11 -ASCII
% rep11 = load ('SCH_final_solution.txt');
% true_optimal_front = load ('schaffer_optimal_front.txt');
f1 = rep11(:,2);
f2 = rep11(:,3);
plot(f1,f2,'x','LineWidth',1.5,...
                'MarkerEdgeColor','r',...
                'MarkerFaceColor',[1 1 1],...
                'MarkerSize',10)
hold on
true_optimal_front = sortrows(true_optimal_front,1);
f1 = true_optimal_front(:,1);
f2 = true_optimal_front(:,2);
plot(f1,f2,'-','LineWidth',1.5,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor',[1 1 1],...
                'MarkerSize',5)
h = legend('A-MOCLPSO','SCH_optimal',0);
set(h,'Interpreter','none')   
xlabel('Objective Function 1')
ylabel('Objective Function 2')
