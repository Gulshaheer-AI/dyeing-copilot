close all;
clear all;
clc
pop = 40;
gen = 100;
CLPSO(pop,gen)