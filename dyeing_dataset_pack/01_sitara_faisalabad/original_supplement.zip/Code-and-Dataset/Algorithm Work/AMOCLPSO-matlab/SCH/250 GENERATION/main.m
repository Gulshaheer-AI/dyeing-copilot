close all;
clear all;
clc
pop = 100;
gen = 250;
CLPSO(pop,gen)