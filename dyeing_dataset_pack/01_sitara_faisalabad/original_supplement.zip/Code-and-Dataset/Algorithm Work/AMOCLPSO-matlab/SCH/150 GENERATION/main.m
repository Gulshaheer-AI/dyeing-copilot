close all;
clear all;
clc
pop = 100;
gen = 150;
CLPSO(pop,gen)