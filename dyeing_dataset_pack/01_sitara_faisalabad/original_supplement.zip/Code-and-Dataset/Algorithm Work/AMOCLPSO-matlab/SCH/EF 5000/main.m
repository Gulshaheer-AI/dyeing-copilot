close all;
clear all;
clc
pop = 50;
gen = 100;
CLPSO(pop,gen)