function f = ZDT3(x, M, V)
f = [];
%Objective function one
f(1) = x(1);
%% Intermediate function
sum = 0;
for i = 2 : V
    sum = sum + (x(i));   
end
g_x = 1 + 9*(sum)/(V-1);
% g_x = 1;
% Objective function two
f(2)= g_x*(1- sqrt(x(1)/(g_x))-(x(1)/g_x)* sin(10*pi*x(1)));
%% Check for error
if length(f) ~= M
    error('The number of decision variables does not match you previous input. Kindly check your objective function');
end