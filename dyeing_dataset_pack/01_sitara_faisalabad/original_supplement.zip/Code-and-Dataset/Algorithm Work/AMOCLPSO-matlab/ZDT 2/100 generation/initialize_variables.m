function swarm = initialize_variables(pop, objectives, dim, min_range, max_range)
% ini_min = 0;
% ini_max = 1;
m = dim + objectives;
vel = m + dim;
pbest = vel + dim;
best_fit = pbest+objectives;
%% Initialize each swarm
for i = 1 : pop
    % Initialize the decision variables based on the minimum and maximum
    % possible values. dim is the number of decision variable. A random
    % number is picked between the minimum and maximum possible values for
    % the each decision variable.
    for j = 1 : dim
        swarm(i,j) = min_range(j) + (max_range(j) - min_range(j))*rand(1);
        swarm(i,m+1:vel)= 0;
    end
%% Objective functions
    swarm(i,dim+1:m) = ZDT2(swarm(i,1:dim), objectives, dim);
%% Personal Best Positions and Objective functions
    swarm(i,vel+1:pbest)= swarm(i,1:dim);
    swarm(i,pbest+1:best_fit)=swarm(i,dim+1:m);
end