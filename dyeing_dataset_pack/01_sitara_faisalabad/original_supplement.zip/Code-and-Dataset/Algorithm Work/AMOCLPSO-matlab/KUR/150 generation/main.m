close all;
clear all;
clc
pop = 100;
gen = 50;
CLPSO(pop,gen)