close all;
clear all;
clc
pop = 100;
gen = 200;
CLPSO(pop,gen)