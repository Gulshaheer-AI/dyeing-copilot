rep11 = load('kur_final_solution.txt');
true_optimal_front = load('kur_front.txt');
true_optimal_front = sortrows(true_optimal_front,1);
f1 = rep11(:,4);
f2 = rep11(:,5);
plot(f1,f2,'x','LineWidth',1.5,...
                'MarkerEdgeColor','r',...
                'MarkerFaceColor',[1 1 1],...
                'MarkerSize',10)
hold on
f1 = true_optimal_front(:,1);
f2 = true_optimal_front(:,2);
plot(f1,f2,'-k','LineWidth',1.5,...
                'MarkerEdgeColor','k',...
                'MarkerFaceColor',[1 1 1],...
                'MarkerSize',5)
h = legend('A-MOCLPSO','KUR_optimal',0);
set(h,'Interpreter','none')   
xlabel('Objective Function 1')
ylabel('Objective Function 2')
