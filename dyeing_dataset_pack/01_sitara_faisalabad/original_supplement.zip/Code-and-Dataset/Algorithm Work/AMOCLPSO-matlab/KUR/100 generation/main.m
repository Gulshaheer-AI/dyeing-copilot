close all;
clear all;
clc
pop = 100;
gen = 100;
CLPSO(pop,gen)