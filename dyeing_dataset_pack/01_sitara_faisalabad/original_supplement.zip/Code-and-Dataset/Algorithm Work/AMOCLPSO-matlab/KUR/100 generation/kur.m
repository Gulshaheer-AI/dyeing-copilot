function f = KUR(x, V)
%% function f = evaluate_objective(x, M, V)
f = [];

sum = 0;
for i = 1:V-1
    sum = sum + (-10*exp(-0.2* sqrt(x(i)^2 + x(i+1)^2)));
end
f(1) = sum;

sum = 0;
for i = 1:V
    sum = sum + ((abs(x(i)))^0.8 + 5* sin(x(i)^3));
end
f(2) = sum;