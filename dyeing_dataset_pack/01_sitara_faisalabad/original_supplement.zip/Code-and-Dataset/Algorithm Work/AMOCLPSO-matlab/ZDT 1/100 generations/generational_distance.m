function generational_distance_metic1 = generational_distance(front,optimal_front,objectives)
ZDT = [];
ZDT = sortrows(front,31);
ZDT4 = ZDT(:,31:32);
q = 1;
ZDT111(1,:)= ZDT4(1,:);
[r2 c2]= size(ZDT4);
while(r2>1)
    [r3 c3]= size(ZDT111);     
    while (sqrt(( ZDT111(r3,1)- ZDT4(1,1))^2 +( ZDT111(r3,2)- ZDT4(1,2))^2) < 0.01)  
        ZDT4(1,:)= [];
        [r2 c2]= size(ZDT4);
        if r2 == 0
            break
        end
    end
    [r2 c2]= size(ZDT4);
    if r2 ~= 0
     q = q+1;
     ZDT111(q,:)= ZDT4(1,:);
     [r2 c2]= size(ZDT4);
    end
end
ZDT = [];
ZDT = ZDT111;
[r1 c1]=size(ZDT);
    clear c1
    [r2 c2]=size(optimal_front);
    clear c2
    euclidean = zeros(1,1);
    min_distances = zeros(1,1);
       for i = 1:r1
           for j = 1:r2
               for k = 1: objectives
                   d = optimal_front(j,k);
                   e = ZDT(i,k);
                   euc(k) = d - e;
               end
               euclidea = 0;
               for a = 1: objectives
                    euclidea = euclidea + (euc(a))^2;
               end
               euclid = sqrt(euclidea);
               if j == 1
                   euclidean = euclid;
               else
                    euclidean = cat(1,euclidean,euclid);
               end                    
           end
           min_distance = min(euclidean);
                if i == 1
                    min_distances = min_distance;
                else
                    min_distances = cat(1,min_distances,min_distance);
                end
       end       
       generational_distance_metic1= sum(min_distances)/r1;